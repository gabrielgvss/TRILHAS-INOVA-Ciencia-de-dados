let ano_atual = 2024;
let ano_nascimento_cliente = prompt(`Digite o ano de nascimento do cliente:`);

let idade = ano_atual - ano_nascimento_cliente;

alert(`O cliente tem ${idade} anos de idade.`);

