let nome = prompt("Digite seu nome para prosseguir:");

if (nome == ""){
    alert("Desculpe, nenhum nome fornecido!");

}else{
    alert(`Olá, ${nome}, seja bem-vindo(a) à nossa empresa!`);
    
}