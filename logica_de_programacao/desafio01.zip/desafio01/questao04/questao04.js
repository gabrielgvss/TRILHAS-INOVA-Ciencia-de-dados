let numero = "";

for (let i = 1; i<=10; i++){
    numero += i + "\t";

}

alert(`Mostrando na tela contagem de 1 - 10:\n${numero}`);