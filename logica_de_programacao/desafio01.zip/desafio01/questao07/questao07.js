let numero1 = prompt(`Digite o primeiro número: `);
let numero2 = prompt(`Digite o segundo número: `);

if (numero1 % numero2 == 0){
    alert(`O número ${numero1} é divisível por ${numero2}`);

}else{
    alert(`O número ${numero1} não é divisível por ${numero2}`);

}
