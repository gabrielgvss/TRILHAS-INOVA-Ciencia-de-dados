let numero = "";

for (let i = 20; i >= 1; i--){
    numero += i + "\t";

}

alert(`Mostrando na tela contagem regressiva de 20 até 1:\n${numero}`);