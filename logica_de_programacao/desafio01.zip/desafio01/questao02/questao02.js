let idade = prompt("Digite sua idade: ");

if (idade >= 60){
    alert("Aguarde na fila de prioridade");

}else{
    alert("Aguarde na fila normal");
    
}