let numero1 = prompt(`Digite o primeiro número: `);
let numero2 = prompt(`Digite o segundo número: `);

resultado = numero1 * numero2;

alert(`O resultado da multiplicação de ${numero1} * ${numero2} = ${resultado}`);
